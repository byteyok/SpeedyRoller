# Speedy Roller Dashboard

Dashboard live per il monitoraggio dei battiti degli atleti, con soglie personalizzate, grafico, notifiche e salvataggio in Excel.

### Come pubblicarlo su [Render.com](https://render.com)

1. Crea un account gratuito su [https://render.com](https://render.com)
2. Crea un repository su GitHub e carica tutti i file di questa cartella
3. Su Render, clicca su "New Web Service"
4. Collegalo al tuo repo GitHub e seleziona `render.yaml`
5. Render pubblicherà la tua app e ti darà un link pubblico!

